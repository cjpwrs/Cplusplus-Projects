#include <iostream> 

using namespace std;

int main()
{
	
	cout << "BYU\nBYU\nBYU" <<endl;
	system("pause");
    return 0;
}