#include "Arena.h"
Arena::Arena()
{
    vector<FighterInterface*> players;
}

bool Arena::addFighter(string info)
{
    stringstream strm(info);
    string name, type;
    int hp, strength, speed, magic;
    if (strm >> name >> type >> hp >> strength >> speed >> magic) //checks for errors 
	{
		if (strm.eof()) //only process if at end of file
		{
			//do not allow non positive hp, strength, speed or magic
			if (hp <= 0 || strength <= 0 || speed <= 0 || magic <= 0) 
			{
				return false;
			}
			//checks to see if name is already in list
			for (int i = 0; i < players.size(); i++) 
			{
				if (name == players[i]->getName())
				{
					return false;
				}
			}
			//add player if not in list already
			if(type == "A")
			{
				Archer* A = new Archer(name, hp, strength, speed, magic);
				players.push_back(A);
			}
			else if (type == "C")
			{
				Cleric* C = new Cleric(name, hp, strength, speed, magic);
				players.push_back(C);
			}
			else if (type == "R")
			{
				Robot* R = new Robot(name, hp, strength, speed, magic);
				players.push_back(R);
			}
			else 
			{
				return false; //if type is not A or C or R
			}
		return true;
		}
		else return false;
	}
	else return false;
}
bool Arena::removeFighter(string name)
{
    for (int i = 0; i < players.size(); i++)
    {
        if (name == players[i]->getName())
        {
            players.erase(players.begin() + i);
            return true;
        }
    }
    return false;
}
FighterInterface* Arena::getFighter(string name)
{
    for (int i = 0; i < players.size(); i++)
    {
        if (name == players[i]->getName())
        {
            return players[i];
        }
    }
    return false;
}
int Arena::getSize()
{
    return players.size();
}