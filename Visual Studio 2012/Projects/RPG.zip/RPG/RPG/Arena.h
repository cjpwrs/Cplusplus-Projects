#include <iostream>
#pragma once
#include <sstream>
#include <vector>
#include "Archer.h"
#include "Robot.h"
#include "Cleric.h"
#include "ArenaInterface.h"
#include "FighterInterface.h"

class Arena : public ArenaInterface
{
public:
    Arena();

	// Given the info string, create a new fighter with the specified characteristics and add him to players
    bool addFighter(string info);

	// Remove a fighter from the arena (when he dies)
    bool removeFighter(string name);

	// Return a pointer to the fighter with the given name so that he can fight
    FighterInterface* getFighter(string name);

	// Return the size of players
    int getSize();
private:
    vector<FighterInterface*> players;
};

